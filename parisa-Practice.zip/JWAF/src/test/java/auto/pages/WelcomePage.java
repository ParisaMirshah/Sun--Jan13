package auto.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static org.testng.Assert.assertEquals;

public class WelcomePage {

    final static String TITLE = "WW (Weight Watchers): Weight Loss & Wellness Help";

    WebDriver driver;
    //String xpathHeading = "//h1";
    //String xpathLink = "//ul/li/a[text()='https://www.weightwatchers.com/us/']";

    public WelcomePage(WebDriver driver) {
        this.driver = driver;
    }

    public WelcomePage verifyWelcomePageTitle() {
        String actualTitle = driver.getTitle();
        assertEquals(actualTitle, TITLE,
                "Actual title doesn't match");
        return this;
    }



    public void clickOnLinkViaLinkText(String link) {
        driver.findElement(By.linkText(link)).click();
    }



}
