package auto.testcases;

public class DictionaryTest {


    //@XlsDataSourceParameters(path = "TestData/DictionaryData/XLsDataSourceParameter.xlsx", sheet = "arQuestion", dsUid = "TUID", dsArgs = "language, arQuestionText, arAnswerText")
    //public void i18nSystemMessageVerificationThroughAutoResponseAcceptedFlow(String language,
}
